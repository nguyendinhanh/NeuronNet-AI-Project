# Test-Build
[![Build Status](https://travis-ci.com/etown-blue-team/Test-Build.svg?branch=master)](https://travis-ci.com/etown-blue-team/Test-Build)
[![codecov](https://codecov.io/gh/etown-blue-team/Test-Build/branch/master/graph/badge.svg)](https://codecov.io/gh/etown-blue-team/Test-Build)
[![Requirements Status](https://requires.io/github/etown-blue-team/Test-Build/requirements.svg?branch=master)](https://requires.io/github/etown-blue-team/Test-Build/requirements/?branch=master)

Test repository for checking out different python systems.
