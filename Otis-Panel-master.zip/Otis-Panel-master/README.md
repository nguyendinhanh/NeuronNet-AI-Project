# Otis-Panel
A web panel to control and use otis in a friendly way
